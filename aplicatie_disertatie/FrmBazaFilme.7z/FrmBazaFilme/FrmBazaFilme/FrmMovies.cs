﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FrmBazaFilme
{
    public partial class FrmMovies : Form
    {
        public FrmMovies()
        {
            InitializeComponent();
        }
        private void FrmMovies_Load(object sender, EventArgs e)
        {
            dgvMovies.DataSource = Global.ds;
            dgvMovies.DataMember = "Movies";

            dgvDetalii.DataSource = Global.ds;
            dgvDetalii.DataMember = "Detalii";
        }
        
        private void dgvRemovedMovies_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void bAddMovies_Click(object sender, EventArgs e)
        {
            FrmAddMovies f = new FrmAddMovies();
            f.ShowDialog();
        }

        private void bUpdateMovie_Click(object sender, EventArgs e)
        {

        }
    }
}
